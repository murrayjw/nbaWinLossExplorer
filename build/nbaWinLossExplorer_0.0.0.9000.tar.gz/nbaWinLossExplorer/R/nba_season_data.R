#' @docType data
#'
#'@description The result of every regular season NBA game 
#'from 1948 to 2021
#'
#' @usage data(nba_season_data)
"nba_season_data"