library(testthat)
library(nbaWinLossExplorer)

test_check("nbaWinLossExplorer")
